exports.help = (prefix,pushname, autorfg) => {
	return ` Hola *@${autorfg}*
͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
┌──────────────
Ⓟ = *_Utilizable Por usuarios Premium_*
☠︎︎ = *_Utilizable por Administradores_*
♔  = *_Utilizable por el dueño del bot_*
└──────────────

≡ *LISTA DE MENUS*
┌───⊷ *STICKER* ⊶
▢ *${prefix}sticker* _(Nombre|Autor)_
▢ *${prefix}sticker2* _(Nombre|Autor)_
▢ *${prefix}take* _(Nombre|Autor)_
♔ *${prefix}exif* _(Nombre|Autor)_
▢ *${prefix}jumbo*
▢ *${prefix}ttp*
▢ *${prefix}ttp2*
▢ *${prefix}attp* 
▢ *${prefix}attp2* 
▢ *${prefix}attp3*
▢ *${prefix}smeme* _(txt|text2)_
▢ *${prefix}smeme2*
▢ *${prefix}toimg* 
▢ *${prefix}togif* 
▢ *${prefix}tovid* 
▢ *${prefix}triggered* 
▢ *${prefix}passed* 
▢ *${prefix}wasted* 
▢ *${prefix}sgay* 
▢ *${prefix}srip* 
▢ *${prefix}scelda* 
└──────────────

┌───⊷ *DESCARGAS* ⊶ 
▢ *${prefix}play* 
▢ *${prefix}play2* 
Ⓟ *${prefix}playvid* 
Ⓟ *${prefix}ytmp3*
Ⓟ *${prefix}ytmp4*
▢ *${prefix}instagram*
▢ *${prefix}igstory*
▢ *${prefix}tiktok*
▢ *${prefix}tiktokaudio*
└──────────────

┌───⊷ *BUSQUEDA* ⊶
▢ *${prefix}ytsearch*
▢ *${prefix}ytstalk*
▢ *${prefix}igstalk*
▢ *${prefix}githubstalk*
▢ *${prefix}Lyrics*
▢ *${prefix}playstore*
└──────────────

┌───⊷ *EDUCACIÓN* ⊶
▢ *${prefix}covid*
▢ *${prefix}hora*
▢ *${prefix}trad*
▢ *${prefix}cal*
▢ *${prefix}google*
▢ *${prefix}wiki*
▢ *${prefix}encode*
▢ *${prefix}decode*
└──────────────

┌───⊷ *MAKER* ⊶
▢ *${prefix}blackpink*
▢ *${prefix}3d*
▢ *${prefix}3dtext*
▢ *${prefix}fakedonald*
▢ *${prefix}halloween*
▢ *${prefix}carbon*
▢ *${prefix}vampire*
▢ *${prefix}matrix*
▢ *${prefix}googletxt*
▢ *${prefix}spider*
▢ *${prefix}express*
▢ *${prefix}dance*
▢ *${prefix}blackbird*
└──────────────

┌───⊷ *MEDIA* ⊶
▢ *${prefix}screenshot*
▢ *${prefix}tourl*
▢ *${prefix}tourl2*
▢ *${prefix}urltoimg*
▢ *${prefix}toav*
▢ *${prefix}tomp3*
▢ *${prefix}asupan*
▢ *${prefix}wame*
▢ *${prefix}ocr*
▢ *${prefix}sinfondo*
▢ *${prefix}escribe*
▢ *${prefix}tinyurl* _(a cortador)_
└──────────────

┌───⊷ *FUN* ⊶
▢ *${prefix}random*
▢ *${prefix}Leermas* _(txt1|txt2)_
▢ *${prefix}fake* _(@tag|txt1|txt2)_
▢ *${prefix}tagme*
▢ *${prefix}mention* _(549xxx)_
▢ *${prefix}say*
└──────────────

┌──⊷ *ECONOMIA* ⊶
▢ *${prefix}shop*
▢ *${prefix}top*
▢ *${prefix}bal*
▢ *${prefix}buy* _(compra 💎)_ 
▢ *${prefix}buygcoin* _(compra 🎰)_ 
♔ *${prefix}adddiama*
♔ *${prefix}addgcoin*
└──────────────

┌───⊷ *JUEGOS* ⊶
▢ *${prefix}shipping* 
▢ *${prefix}pregunta*
▢ *${prefix}VoR* <verdad/reto>
▢ *${prefix}topgay*
▢ *${prefix}ttc* <@tag>
▢ *${prefix}delttc*
▢ *${prefix}mates*
▢ *${prefix}slot*
▢ *${prefix}ppt*
└──────────────

┌───⊷ *IMAGEN* ⊶
▢ *${prefix}imagen*
▢ *${prefix}pinterest*
▢ *${prefix}wallpaper*
▢ *${prefix}loli*
▢ *${prefix}neko*
▢ *${prefix}waifu*
▢ *${prefix}girl*
▢ *${prefix}man*
▢ *${prefix}rip*
└──────────────

┌───⊷ *GRUPO* ⊶
▢ *${prefix}infogp*
▢ *${prefix}infodetec*
☠︎︎ *${prefix}group* _(Close/Open)_
▢ *${prefix}link*
▢ *${prefix}online*
☠︎︎ *${prefix}kick*
▢ *${prefix}staff*
▢ *${prefix}dueñogp*
☠︎︎ *${prefix}setdesc*
☠︎︎ *${prefix}setname*
☠︎︎ *${prefix}anularlink*
▢ *${prefix}getbio* _<@tag>_
▢ *${prefix}perfil+* _<@tag>_
▢ *${prefix}perfil*
▢ *${prefix}nivel*
▢ *${prefix}rangos*
▢ *${prefix}leido* _(Mensaje bot)_ 
☠︎︎ *${prefix}leveling* _(on/off)_
☠︎︎ *${prefix}welcome* _(on/off)_
☠︎︎ *${prefix}goodbye* _(on/off)_
☠︎︎ *${prefix}antilinkwha* _(on/off)_
☠︎︎ *${prefix}antilinktelegram* _(on/off)_
☠︎︎ *${prefix}antilinkdiscord* _(on/off)_
☠︎︎ *${prefix}nsfw* _(on/off)_
☠︎︎ *${prefix}delete* _(Mensaje bot)_
☠︎︎ *${prefix}salir* _(dejo el grupo)_
└──────────────

  ≡  Estos comandos menciona a todos los usuarios de un grupo
┌───⊷ *MENSIONES* ⊶
☠︎︎ *${prefix}tagall* 
☠︎︎ *${prefix}notify* _(txt)_
☠︎︎ *${prefix}hidetag*
▢ *${prefix}contag* _(Nombre|Num)_
▢ *${prefix}sticktag*
▢ *${prefix}imgtag*
└──────────────

┌───⊷ *SESSION* ⊶
Ⓟ *${prefix}serbot*
▢ *${prefix}stopbot*
▢ *${prefix}listbots*
└──────────────

┌───⊷ *ADVANCE* ⊶
▢ *${prefix}blocklist*
▢ *${prefix}banlist*
▢ *${prefix}listbanchat*
▢ *${prefix}liststickcmd*
▢ *${prefix}getstickcmd*
▢ *${prefix}premiumlist*
▢ *${prefix}checkpremium*
└──────────────

≡ *MENU OWNER* <♔>
┌───⊷ *OWNER* ⊶
▢ *${prefix}Actualizar*
▢ *${prefix}modo* _<publico/privado>_
▢ *${prefix}stickcmd*
▢ *${prefix}delstickcmd*
▢ *${prefix}addprem*
▢ *${prefix}delprem*
▢ *${prefix}setprefix*
▢ *${prefix}ban*
▢ *${prefix}unban*
▢ *${prefix}clearchat*
▢ *${prefix}buscarmsg*
▢ *${prefix}listagp*
▢ *${prefix}antillamada*
▢ *${prefix}antidelete*
▢ *${prefix}autoread*
▢ *${prefix}informes*
▢ *${prefix}solicitudes*
▢ *${prefix}clonar*
▢ *${prefix}banchat*
▢ *${prefix}unbanchat*
└──────────────
`
	
	} 